package com.cc.iosconnect;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/** 2x2 grid: Data | Wi-Fi  /  Hotspot | Bluetooth. Order badalna ho to neeche array badlo. */
public class ClusterView extends ViewGroup {
    private final TileView[] tiles = new TileView[4];

    public ClusterView(Context c) {
        super(c);
        setClipChildren(false);
        int[] kinds = {TileView.DATA, TileView.WIFI, TileView.HOTSPOT, TileView.BT};
        for (int i = 0; i < 4; i++) {
            tiles[i] = new TileView(c, kinds[i]);
            addView(tiles[i]);
        }
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        int h = MeasureSpec.getSize(hSpec);
        setMeasuredDimension(w, h);
        int pad = dp(14), gap = dp(10);
        int cell = Math.max(0, Math.min((w - 2 * pad - gap) / 2, (h - 2 * pad - gap) / 2));
        int spec = MeasureSpec.makeMeasureSpec(cell, MeasureSpec.EXACTLY);
        for (View t : tiles) t.measure(spec, spec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int w = r - l, h = b - t;
        int gap = dp(10);
        int cell = tiles[0].getMeasuredWidth();
        int sx = (w - (2 * cell + gap)) / 2;
        int sy = (h - (2 * cell + gap)) / 2;
        for (int i = 0; i < 4; i++) {
            int x = sx + (i % 2) * (cell + gap);
            int y = sy + (i / 2) * (cell + gap);
            tiles[i].layout(x, y, x + cell, y + cell);
        }
    }
}
